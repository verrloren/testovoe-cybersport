from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_bcrypt import Bcrypt 
from datetime import timedelta

from flask_cors import CORS

db = SQLAlchemy()

from flask_jwt_extended import JWTManager

def create_app():

    app = Flask(__name__,)
    CORS(app, origins= ["https://hackathon-evrz.vercel.app", "https://evraza-hack-397b0f94f4a5.herokuapp.com", "https://still-weekly-tortoise.ngrok-free.app"], expose_headers="*", supports_credentials=True, ) # https://hackathon-evrz.vercel.app

    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://neondb_owner:0LSTmjlMy7tz@ep-odd-recipe-a21ehrv8.eu-central-1.aws.neon.tech/neondb?sslmode=require'

    app.config['SESSION_COOKIE_SAMESITE'] = 'None'  # Для работы с cookie между разными доменами
    app.config['SESSION_COOKIE_SECURE'] = True  # Для HTTPS
    app.config['REMEMBER_COOKIE_SAMESITE'] = 'None' # Если используешь remember_me
    app.config['REMEMBER_COOKIE_SECURE'] = True     # Для remember_me куки

    app.config['SESSION_COOKIE_HTTPONLY'] = True  # Отключить HttpOnly для сессионных cookies

    app.config['JWT_SECRET_KEY'] = 'cdb9e9cee58fefccfba0263b00592f4fbee643a222d0dbaec754443577d5f653'

    app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(days=30)  # Example: 15 minutes
    app.config["JWT_REFRESH_TOKEN_EXPIRES"] = timedelta(days=30)    # Example: 30 days

    #app.secret_key = 'fgigrkfpe14t42gl01'


    jwt = JWTManager(app)

    db.init_app(app)

    from models import User

    bcrypt = Bcrypt(app)

    from routes import register_routes

    register_routes(app, db,bcrypt)

    migrate = Migrate(app, db)

    return app


