from app import db

class Role:
    USER = 'user'
    ADMIN = 'admin'
    MODERATOR = 'moderator'

class User(db.Model):
    __tablename__ = 'User'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String, unique=True, nullable=False)
    email = db.Column(db.String, unique=True, nullable=False)
    password = db.Column(db.String, nullable=False)
    role = db.Column(db.String(50), default=Role.USER)  # Добавляем поле role
    
    projects = db.relationship('Project', backref='user')
    user_guidelines = db.relationship('UserGuideLine', backref='user')

    def __repr__(self, ):
        return f'<User: {self.username}, Role: {self.role}'

    def get_id(self):
        return self.id

class Project(db.Model):
    __tablename__ = 'Project'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable = False)
    user_id = db.Column(db.Integer, db.ForeignKey('User.id'))  # Added foreign key for user
    last_edit_date = db.Column(db.DateTime)

    code_reviews = db.relationship('CodeReview', backref='project')
    project_status = db.Column(db.String)

    def to_dict(self):
    # Преобразуем атрибуты объекта в словарь
        return {"id": self.id, "name": self.name, "user_id": self.user_id, "last_edit_date": self.last_edit_date, "project_status" : self.project_status, "code_reviews": [review.to_dict() for review in self.code_reviews],}

class CodeReview(db.Model):
    __tablename__= 'CodeReview'

    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('Project.id'))

    project_review = db.Column(db.String)

    issues = db.relationship('Issue', backref='codereview')


    def to_dict(self):
    # Преобразуем атрибуты объекта в словарь
        return {"id": self.id, "project_ud": self.project_id, "project_review":self.project_review, "issues":[issue.to_dict() for issue in self.issues]} 




class Issue(db.Model):
    __tablename__ = 'Issue'

    id = db.Column(db.Integer, primary_key=True)
    codereview_id = db.Column(db.Integer, db.ForeignKey('CodeReview.id'), nullable=False)

    type_of_issue = db.Column(db.String) #Architectural, Structure, Package, Naming, Style, Standard
    file_path = db.Column(db.String)
    line_number = db.Column(db.String)
    line_snippet = db.Column(db.String)
    issue_body = db.Column(db.String)
    suggestions = db.Column(db.String)
    suggested_code = db.Column(db.String)

    def to_dict(self):
        # Преобразуем атрибуты объекта в словарь
        return {"id": self.id
                , "type_of_issue": self.type_of_issue
                , "file_path": self.file_path
                , "line_number": self.line_number
                , "line_snippet": self.line_snippet
                , "issue_body": self.issue_body
                , "suggestions": self.suggestions
                , "suggested_code": self.suggested_code}





class GuideLine(db.Model):
    __tablename__ = 'GuideLine'

    id = db.Column(db.Integer, primary_key=True)
    codelang_code = db.Column(db.String, nullable=False) # py, ts, sharp 

    name = db.Column(db.String, nullable=False)
    text = db.Column(db.String, nullable=False)
    
    user_guidelines = db.relationship('UserGuideLine', backref='guideline')

    def to_dict(self):
    # Преобразуем атрибуты объекта в словарь
        return {"id": self.id, "codelang_code": self.codelang_code, "name": self.name, "text": self.text}




class UserGuideLine(db.Model): #Выступает в качестве прослойки между юзером и гайдланами, чтобы не дублировать код. 
    __tablename__ = 'UserGuideLine'

    id = db.Column(db.Integer, primary_key = True)
    guideline_id = db.Column(db.Integer, db.ForeignKey('GuideLine.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('User.id'), nullable=False)
    is_default = db.Column(db.Boolean, nullable=False, default=False)


# Создаем юзера -- назначаем ему дефолтными гайдлайны с индексом 1, 2, 3 для каждого языка.

""" 

У Юзера есть дефолтные настройки гайдлайнов. Они применяются к проектам. При этом юзер может поменять гайдлайн для каждого проекта.
Т.е у юзера есть доступ к CodeLang, которая ссылается на UserGuideLines для этого юзера. Базово создаются вместе с юзером и имеют дефолтные настройки. 
Также есть ProjectGuideLines при создании проекта. В них переносятся данные UserGuideLines c флагом default. 
CodeLang создается для юзера, ссылается как на UserGuideLines так и на ProjectGuideLines Х




errors - прямые ошибки в коде, которые ломают его и мешают выполнению
warnings - ошибки, которые потенциально могут вызвать проблемы, нежелательные ошибки и т.д
arch_issues - Ошибки в архитектуре проекта
package_issues - Ошибки в установленных пакетах и заимствованиях(несоответствие установленных пакетов принятым стандартам)
naming_issues - Ошибки в нейминге функций, переменных и т.д 
style_issues - Отклонения от принятого по гайдлайну стиля кодаа
standard_issues - Все остальные несоответствия стандартам компании.

Пробежали по первому - скормили

Попробуй mistral nemo через ollama потом codestral


Надо структуризировать гайдлайн по этим ошибкам. Сделать форму создания нового гайдлайна по списку


Моя задача сейчас: 

1. Дать беку все, что ему надо
2. Оттестировать загрузку файлов
3. Подкрутить структуризованный гайдлайн.
4. Создать определение по языку всех необходимых для оценки и анализа файлов.
5. Загружать соответствующий гайдлайн, вместе с ошибками, выданными линтером
6. Где раг? Раг в том, что мы выбираем из базы данных необходимые к языку значения. 
Можно порезать файлы с их code review на функции, и модули там где есть комментарии и модель будет по косинусам находить
Подходящую к текущему варианту.
7. Паковать инференс модели в подходящий формат .md

"""

#GuideLine {
#
#id
#name
#text
#
#} 
#















#class Member(db.Model):
#    __tablename__ = 'Member'
#
#
#    id = db.Column(db.String, primary_key=True)
#    name = db.Column(db.String, nullable=False)
#    dateOfBirth = db.Column(db.DateTime, nullable=False)
#    taroCard = db.Column('TaroCard', nullable=True)
#    taroCardid = db.Column(db.String, nullable=True)
#    teamId = db.Column(db.String, nullable=False)
#    team = db.Column('Team', nullable=False)
#
#
#class Interviewee(db.Model):
#    __tablename__ = 'Interviewee'
#
#
#    id = db.Column(db.String, primary_key=True)
#    name = db.Column(db.String, nullable=False)
#    dateOfBirth = db.Column(db.DateTime, nullable=False)
#    taroCardName = db.Column('TaroCard', nullable=True)
#    taroCardId = db.Column(db.String, nullable=True)
#    
#    compatibilityTaro = db.Column(db.String, nullable=True)
#    compatibilityAstro = db.Column(db.String, nullable=True)
#
#    teamName = db.Column(db.String, nullable=False)
#    teamId = db.Column('Team', nullable=False)
#
#
#class Team(db.Model):
#    __tablename__ = 'Team'
#    
#    # Primary key
#    id = db.Column(db.String, primary_key=True, default=lambda: str(uuid.uuid4()))
#    
#    # Attributes
#    name = db.Column(db.String, nullable=False)
#    description = db.Column(db.String, nullable=True)  # Nullable field for description
#    userId = db.Column(db.String, nullable=False)  # Assuming userId is a foreign key to another table
#    
#    # Relationships
#    members = db.relationship('Member', back_populates='team')
#    interviewees = db.relationship('Interviewee', back_populates='teamName')
#    result = db.relationship('Result', back_populates='team')
#
#    def __repr__(self):
#        return f'<Team {self.name}>'
#
#
#class Member(db.Model):
#    __tablename__ = 'Member'
#    
#    id = db.Column(db.String, primary_key=True, default=lambda: str(uuid.uuid4()))
#    name = db.Column(db.String, nullable=False)
#    dateOfBirth = db.Column(db.DateTime, nullable=False)
#    cityOfBirth = db.Column(db.String)
#    countryOfBirth = db.Column(db.String)
#
#    taroCardid = db.Column(db.String, db.ForeignKey('TaroCard.id'))  # taroCardid из Prisma
#    teamId = db.Column(db.String, db.ForeignKey('Team.id'))  # teamId из Prisma
#
#    taroCard = db.relationship('TaroCard', back_populates='members')
#    team = db.relationship('Team', back_populates='members')  # Ensure this is correct
#
#    def __repr__(self):
#        return f'<Member {self.name}>'
#
#
#class Interviewee(db.Model):
#    __tablename__ = 'Interviewee'
#    
#    id = db.Column(db.String, primary_key=True, default=lambda: str(uuid.uuid4()))
#    name = db.Column(db.String, nullable=False)
#    dateOfBirth = db.Column(db.DateTime, nullable=False)
#    cityOfBirth = db.Column(db.String)
#    countryOfBirth = db.Column(db.String)
#
#    taroCardId = db.Column(db.String, db.ForeignKey('TaroCard.id'))  # taroCardId из Prisma
#    teamId = db.Column(db.String, db.ForeignKey('Team.id'))  # teamId из Prisma
#
#    taroCard = db.relationship('TaroCard', back_populates='interviewees')
#    teamName = db.relationship('Team', back_populates='interviewees')  # Ensure this is correct
#    result = db.relationship('Result', back_populates='interviewee')
#    # predictResult = db.relationship('PredictResult', back_populates='interviewees')  # Ensure this is correct
#
#
#    def __repr__(self):
#        return f'<Interviewee {self.name}>'
#
#
#class TaroCard(db.Model):
#    __tablename__ = "TaroCard"
#    
#    
#    id = db.Column(db.String, primary_key=True,)
#    name = db.Column(db.String)
#    url = db.Column(db.String)
#    meaning = db.Column(db.String)
#    strength = db.Column(db.String)
#    weakness = db.Column(db.String)
#    
#    # Correctly define relationships back to Member and Interviewee
#    members = db.relationship("Member", back_populates="taroCard")
#    interviewees = db.relationship("Interviewee", back_populates="taroCard") 
#    result = db.relationship("Result", back_populates="card")
#
#    def __repr__(self):
#        return f'<TaroCard {self.name}>'
#
#class Result(db.Model):
#
#    __tablename__ = 'Result'  # Optional: specify the table name, defaults to class name
#
#    id = db.Column(db.String, primary_key=True, default=lambda: str(uuid.uuid4()))
#    date = db.Column(db.DateTime)
#
#    teamId = db.Column(db.String, db.ForeignKey('Team.id'), nullable=False)
#    team = db.relationship('Team', back_populates="result")
#
#    intervieweeId = db.Column(db.String, db.ForeignKey('Interviewee.id'), nullable=False)
#    interviewee = db.relationship('Interviewee', back_populates="result")
#
#    cardId = db.Column(db.String, db.ForeignKey('TaroCard.id'))
#    card = db.relationship('TaroCard', back_populates="result")
#
#    compatibilityTaroPercent = db.Column(db.String, nullable=True)
#    compatibilityTaroDescription = db.Column(db.String, nullable=True)
#
#    compatibilityAstroPercent = db.Column(db.String, nullable=True)
#    compatibilityAstroDescription = db.Column(db.String, nullable=True)
#

#
    #class PredictedResult(db.Model):
    #__tablename__ = 'PredictedResult'
    #
    #
    #id = db.Column(db.String, primary_key=True, default=lambda: str(uuid.uuid4()))
    #
    #intervieweeId = db.Column(db.String, db.ForeignKey('Interviewee.id'))
    #result = db.Column(db.String)
    #percentage = db.Column(db.String)
    #
    #interviewees = db.relationship("Interviewee", back_populates="predictResult")
    #
    #
        #def __repr__(self):
#return f'<Result {self.result}>'
#

