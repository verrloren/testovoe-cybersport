def generate_report(project_name, project_date, issues):
    '''
    Посчитать кол-во нарушений
    '''
    archint = 0 
    strucint = 0
    nameint = 0
    styleint = 0 
    imporint = 0 
    standardint = 0
    
    for issue in issues:
        if issue.type_of_issue == 'Нарушения в названиях':
            nameint += 1
        elif issue.type_of_issue == 'Архитектурные нарушения':
            archint += 1 
        elif issue.type_of_issue == 'Структурные нарушения':
            strucint += 1 
        elif issue.type_of_issue == 'Нарушения правил импортирования':
            imporint += 1
        elif issue.type_of_issue == 'Стилистические нарушения':
            styleint += 1
        elif issue.type_of_issue == 'Несоответствие стандартам компании':
            standardint += 1 


    return_file = f'''
    Анализ проекта ```{project_name}``` от {project_date}
    ---
    Дата последнего изменения: {project_date}

    Общее кол-во нарушений:
    Архитектурных: {archint}
    Структурных: {strucint}
    В наименованиях: {nameint}
    Несоответствия стиля: {styleint}
    Нарушения в правилах импортирования: {imporint}
    Несоответствий стандартам: {standardint}
    
    '''

    for issue in issues: 
        return_file += f'''
        ### {issue.type_of_issue}
        {issue.file_path} {issue.line_number}
        {issue.line_snippet}
        {issue.body}
        {issue.suggestions}
        {issue.suggested_code}
        '''

    # Запись в файл с расширением .md
    with open("report.md", "w") as file:
        file.write(markdown_content)
        return file
    