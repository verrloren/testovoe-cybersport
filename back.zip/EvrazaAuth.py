from models import User, UserGuideLine

from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity

from flask import jsonify, request, session


def is_logged():
    
    current_user_id = int(get_jwt_identity())
    user = User.query.get(current_user_id)

    if user:
        return jsonify({'success':True, 'response':f'Current user is {user.username}'})
    else:
        return jsonify({'success':False,'response':'No user logged in'}), 401

def create_user(username, email, password, bcrypt, db):
    
    same_username = User.query.filter(User.username == username).first() 
    if same_username: return jsonify({'success':False,'response':f'User is not created, user with username:{username} already exists\n'}), 401
    same_mail = User.query.filter(User.email == email).first()
    if same_mail: return jsonify({'success':False,'response':f'User is not created, user with mail:{email} already exists\n'}), 401
    
    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    #TODO: False version
    user = User(username = username, email=email, password=hashed_password)

    db.session.add(user)
    db.session.flush()

    create_default_guidelines(user, db)

    db.session.commit()

    return jsonify({'success':True, 'response':f'User created with username: {username}'})

def create_default_guidelines(user, db):

    for id, lang in ((1, 'py'), (2, 'ts'), (3, 'sharp')): 
        guideline = UserGuideLine(guideline_id = id, user_id = user.id, is_default = True)
        db.session.add(guideline)
        db.session.flush()

def delete_user(username, db):

    User.query.filter(User.username == username).delete()
    db.session.commit()
    #TODO: False version

    return jsonify({'success':True, 'response':f'Deletion success user: {username}'})
    

def login(email, password, bcrypt):
    

    user = User.query.filter(User.email == email).first()
    if not user: 
        return jsonify({'success':False, 'response':'User not found'}), 401

    if bcrypt.check_password_hash(user.password, password):

        access_token = create_access_token(identity=str(user.id))

        return jsonify({'success':True,'access_token':access_token}), 200 
    else:
        return jsonify({'success':False,'response':'Login failed'}), 401

