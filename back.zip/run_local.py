from app import create_app
import os 

flask_app = create_app()



if __name__=='__main__':

    flask_app.run(host='127.0.0.1', threaded=True, port=5555, debug=True)

