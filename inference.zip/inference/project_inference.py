from inference import one_inference 

def project_inference(project_path):
    

    import os
    
    def generate_tree_structure(folder_path: str) -> str:
        """
        Генерирует дерево структуры папок и файлов.
        :param folder_path: Путь до папки.
        :return: Текстовая структура дерева.
        """
        result = []
    
        for root, dirs, files in os.walk(folder_path):
            # Относительный путь относительно корневой папки
            relative_root = os.path.relpath(root, folder_path)
            indent = "  " * (relative_root.count(os.sep))  # Отступ для вложенности
    
            result.append(f"{indent}{relative_root}/")
            for dir_name in sorted(dirs):
                result.append(f"{indent}  {dir_name}/")
            for file_name in sorted(files):
                result.append(f"{indent}  {file_name}")
        
        return "\n".join(result)

    def count_file_types(tree_structure: str):
        """
        Подсчитывает количество файлов с расширениями .py, .ts и .cs в строках структуры дерева.
        :param tree_structure: Структура дерева, полученная из функции generate_tree_structure.
        :return: Строка с количеством файлов и типом файла, который встречается чаще всего.
        """
        py_count = 0
        ts_count = 0
        cs_count = 0

        # Проходим по каждой строке структуры дерева
        for line in tree_structure.splitlines():
            # Проверяем, если это файл, а не папка
            if line.strip().endswith('.py'):
                py_count += 1
            elif line.strip().endswith('.ts'):
                ts_count += 1
            elif line.strip().endswith('.cs'):
                cs_count += 1

        # Определяем, какого типа файлов больше
        if py_count > ts_count and py_count > cs_count:
           return 'python' 
        elif ts_count > py_count and ts_count > cs_count:
           return 'typescript' 
        elif cs_count > py_count and cs_count > ts_count:
           return 'sharp' 
        else:
            return 'python'

    tree_structure = generate_tree_structure(project_path)

    lang = count_file_types(tree_structure)

    paths = {

        'python' : [
            'inference/python/python_errors_naming.txt',
        'inference/python/python_errors_arch.txt',
        'inference/python/python_errors_package.txt',
        'inference/python/python_errors_structure.txt',
        'inference/python/python_errors_standards.txt',
        'inference/python/python_errors_style.txt',
                    ],

        'sharp' : [
            'inference/sharp/sharp_errors_naming.txt',
        'inference/sharp/sharp_errors_arch.txt',
        'inference/sharp/sharp_errors_package.txt',
        'inference/sharp/sharp_errors_structure.txt',
        'inference/sharp/sharp_errors_standards.txt', 
        'inference/sharp/sharp_errors_style.txt',   
        ],

        'typescript' : [
            'inference/typescript/ts_errors_naming.txt',
        'inference/typescript/ts_errors_arch.txt',
        'inference/typescript/ts_errors_package.txt',
        'inference/typescript/ts_errors_structure.txt',
        'inference/typescript/ts_errors_standards.txt', 
        'inference/typescript/ts_errors_style.txt',    

        ]

    }

    suffixes = {

            'python' : ['.py', '.pyp'],
            'sharp' : ['.cs'],
            'typescript' : ['.ts', '.tsx'] 
    }

    path_list = paths[lang]
    suffix = suffixes[lang]

    
    def generate_file_contents(folder_path: str, file_extensions: list) -> str:
        """
        Генерирует текст с содержимым файлов указанных расширений и добавляет номер строки.
        :param folder_path: Путь до папки.
        :param file_extensions: Список расширений файлов (например, [".txt", ".log"]).
        :return: Текст с путями, содержимым файлов и номерами строк.
        """
        result = []
        
        for root, _, files in os.walk(folder_path):
            for file_name in files:
                # Проверяем, что расширение файла есть в списке
                if any(file_name.endswith(ext) for ext in file_extensions):
                    file_path = os.path.join(root, file_name)
                    relative_path = os.path.relpath(file_path, folder_path)
        
                    # Считываем содержимое файла
                    try:
                        with open(file_path, "r", encoding="utf-8") as f:
                            content_lines = f.readlines()
                    except Exception as e:
                        content_lines = [f"Ошибка чтения файла: {e}"]
        
                    result.append(f"Path: {relative_path}")
                    
                    # Добавляем номер строки и содержимое каждой строки
                    for line_number, line in enumerate(content_lines, 1):
                        result.append(f"  Line {line_number}: {line.strip()}")
                    
                    result.append("")  # Разделение для удобства
            
        return "\n".join(result)
    
 
    # Генерация содержимого файлов с номерами строк
    file_contents = generate_file_contents(project_path, suffix)
    
    # Объединение результата
    code = f"Tree Structure:\n{tree_structure}\n\nFile Contents:\n{file_contents}"

    type_list = [
        
        'naming',
        'architecture',
        'package',
        'structure',
        'standards', 
        'style',

    ]


    print(code)
    json_list = []

    for typ, guideline_path in zip(type_list, path_list):
    
        json_list.append(one_inference.get_inference(typ, guideline_path, code)) 

    return json_list

