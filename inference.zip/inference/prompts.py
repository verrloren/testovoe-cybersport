def naming_prompt(guide, code):
    return     f'''You are a senior software architect in an IT company. Your task is to perform a **naming convention review** of the provided code and project structure. Using the provided guidelines `{guide}`, analyze the code `{code}` and ensure that all names strictly follow the naming conventions and best practices described in the guideline.
    
    ### **Instructions**:
    
    1. **Analyze Naming**:
       - Evaluate all identifiers in the code and project structure, including:
         - **Variables**
         - **Functions**
         - **Classes**
         - **Files and directories**
         - **Constants**
         - Names must be consistent with the prescribed case style (e.g., snake_case, PascalCase, camelCase, etc.).
         - Names must be meaningful, descriptive, and concise.
         - Names should avoid ambiguity, abbreviations (unless explicitly allowed), and excessive length.
         - Reserved keywords or special characters should not be used inappropriately.
         - Check for uniformity in naming across the entire project.
         - Do not check imports for naming conventions 
    
    2. **Identify Issues**:
       - Document any names that violate the naming conventions.
       - Suggest alternative names that align with the conventions.
    
    3. **Output Format**:
       - Return your findings in a strict **JSON format** to ensure that the results are machine-readable and easy to parse.
       - Use the following structure:
       
       ```json
       {{
         "naming_review": [
           {{
             "type": "naming",
             "file_name": "<Name of the file with full path>",
             "line_number": "<Line number of the identified name>",
             "line_snippet": "<Text of line with poor naming>",
             "issues": [
               "<List all identified issues with the name>"
             ],
             "suggested_name": "<Suggested name that adheres to the guideline>",
             "reasoning": "<Reasoning for the suggested change>"
           }}
         ],
         
         "project_review": "<Provide an overall review of the project's naming consistency. Are names meaningful, consistent, and compliant with the guideline?>"
       }}
    4. Validation and Final Answer:
    Validate that the JSON is complete, accurate, and adheres strictly to the specified structure.
    If no naming issues are found, explicitly state this in the project_review section.Give your answer in Russian.'''

def architecture_prompt(guide, code):
    return f'''You are a team lead in an IT company. Based on the provided guideline information `{guide}`, perform an **architectural code review** and refactoring for the provided code and project structure: `{code}`. Your focus is strictly on architecture. Ensure your analysis and suggestions adhere strictly to the guidelines provided.

### **Instructions**:

1. **Analyze Architectural Layers**:
   - Examine the project and code line by line, as well as holistically, to identify architectural issues, inefficiencies, and deviations from the best practices defined in the guideline.
   - Specifically, ensure that:
     - The project structure adheres to proper **separation of concerns**:
       - **Business logic**, **service layer**, and **integration layer** must be clearly isolated.
     - **Primary and secondary adapters** are located in the same directory and follow organizational consistency.
     - The code is modular, reusable, and adheres to architectural best practices.

2. **Identify Issues**:
   - Clearly document each identified architectural issue. For example:
     - Violations of separation of concerns.
     - Overly coupled layers or modules.
     - Lack of adherence to guidelines regarding adapters or layer organization.
   - Provide detailed reasoning for why each issue is a problem, referencing the provided guideline.

3. **Propose Refactoring**:
   - For each identified architectural issue:
     - Suggest a precise and practical solution.
     - Provide refactored code snippets or adjustments to project structure that adhere to the guidelines.

4. **Output Format**:
   - Your response must be in a **strict JSON format**, machine-readable and parsable. Avoid writing anything outside this format.
   - Use the following structure:
   ```json
   {{
     "code_review": [
       {{
         "type": "architecture",
         "file_name": "<Name of the file with full path>",
         "line_number": "<Line number of the code snippet IF APPLICABLE>",
         "line_snippet": "<Original line of code>",
         "issues": [
           "<List all identified architectural issues, inefficiencies, or deviations from guidelines>"
         ],
         "improvements": [
           "<List improvements based on identified issues>"
         ],
         "suggested_code": [
           "<Refactored code for this line>"
         ]
       }}
     ],
     "project_review": "<Provide your overall architectural review of the project based on the guidelines. Does it follow the principles outlined in the provided text? Is the architecture consistent with the described layers and structure?>"
   }}
Final Validation:
Ensure your JSON output is complete, accurate, and adheres strictly to the provided structure.
If no issues are identified, explicitly state this in the project_review section.Give your answer in Russian.'''


def structure_prompt(guide, code):
    return f'''You are a team lead in an IT company. Based on the provided guideline information {guide}, conduct a **structural code review** and suggest necessary refactoring for the following code and project structure: {code}. Your focus is strictly on verifying and improving the structure of the code and project layout. Stick to the guidelines provided and follow the steps below:

### **Instructions**:

1. **Analyze Project Structure and Code**:
   - Review the **entire project structure** and **each line of the code** for deviations from the provided guidelines.
   - Focus on the **organization and structure** of files, folders, and layers.

2. **Check for Structural Compliance**:
   - Ensure the project follows a **monorepository layout**.
   - Verify the presence and correctness of key configuration files:
     - `.gitignore`
     - `.editorconfig`
     - `.gitattributes`
     - Deployment configuration for CI/CD pipelines.
   - Confirm **documentation requirements**:
     - Technical docs in the `docs/` directory (including PlantUML schemas, if applicable).
     - Business process documentation.
   - Ensure proper separation of components:
     - Backend (`demo_project_backend`) and frontend must be clearly separated.
     - Backend must follow Python packaging best practices (`setup.py`, `pyproject.toml`, `setup.cfg`).
   - Validate that `README.md` includes:
     - Setup instructions.
     - Information on permissions and group structures.
   - Check for a **clear separation of concerns**:
     - Business logic, service layer, and integration layer should be well-isolated.
     - Primary and secondary adapters must reside in the same directory.

3. **Identify Issues and Propose Solutions**:
   - For each identified structural issue, clearly document:
     - **The issue**: What is wrong or deviates from the guidelines?
     - **Reasoning**: Why is this an issue based on the provided guidelines?
     - **Solution**: How to fix it (specific code or structural changes).

4. **Strict JSON Format**:
   - Return your response in the following JSON format to ensure it is machine-readable:
   ```json
   {{
     "code_review": [
       {{
         "type": "structure",
         "file_name": "<name of the file with full path>",
         "line_number": "<Line number of the code snippet IF APPLICABLE>",
         "line_snippet": "<Original line of code>",
         "issues": [
           "<List all identified structural issues, inefficiencies, or deviations from guidelines>"
         ],
         "improvements": [
           "<List improvements based on identified issues>"
         ],
         "suggested_code": [
           "<Refactored code for this line>"
         ]
       }}
     ],
     "project_review": "<Provide your overall structural review of the project based on the guidelines. Does it follow the principles outlined in the provided text? Is the structure consistent with the described layers and organization?>"
   }}
5. Validation and Final Answer:
Validate the generated JSON against the guidelines, the provided project structure, and the code.
Return a final answer, ensuring that it strictly adheres to the guidelines.
If no issues are identified, explicitly state so in the project_review section.
Give your answer in Russian.
'''

def package_prompt(guide, code):
    return f'''You are a team lead in an IT company. Based on the provided guideline information and company standards {guide}, analyze the provided code {code} to identify any imports present in the code that are not mentioned in the guideline. Your focus is strictly on the imports.

Follow these steps:

1. Parse the code and extract all import statements. Compare each import against the allowed imports listed in the standards.  
2. For each import that is not found in standards, clearly document it and provide reasoning for its identification as a deviation.  
3. Suggest actions for handling the identified deviations. For example: Should the import be removed? Should it be documented in the guideline?  
4. Your answer must be in a strict JSON format, machine-readable, and parsable. Avoid writing anything outside this JSON format.

Use the following structure:
{{
  "import_review": [
    {{
      "file_name": "<Name of the file with full path>",
      "import_statement": "<Exact import statement from the code>",
      "issues": ["<List of issues or deviations identified with the import>"],
      "recommendations": ["<Recommended actions for handling the deviation>"]
    }}
  ],
  "summary": "<Provide an overall summary of your findings. Are there imports in the code that are not allowed by the guideline?>"
}}

Return your response in the above JSON format. If no deviations are found, explicitly state so in the `summary`.Give your answer in Russian.'''

def style_prompt(guide, code):
    return f'''You are a senior software engineer in an IT company. Your task is to perform a **code style review** for the provided code and project structure. Using the provided guidelines `{guide}`, analyze the code `{code}` and ensure that it adheres to the coding style standards defined in the guideline.

### **Instructions**:

1. **Analyze Code Style**:
   - Review the entire project to check for consistency and adherence to the following style elements:
     - **Indentation** (e.g., spaces vs. tabs, number of spaces per indentation level).
     - **Line length** (ensure lines do not exceed the maximum allowed length, typically 80 or 120 characters).
     - **Whitespace usage** (before/after operators, around parentheses, and after commas).
     - **Naming conventions** (refer to the previous naming conventions section).
     - **Function and method definitions** (e.g., proper spacing between function arguments and function body).
     - **Commenting style** (ensure comments are used appropriately and adhere to formatting guidelines, such as docstrings for functions/classes).
     - **Blank lines** (ensure there are proper blank lines between functions, classes, and code blocks).
     - **Import style** (grouping imports, ordering them correctly).
   - Ensure that the project follows the style guide, whether it's PEP 8, Google Python Style Guide, or any custom style guide defined in `.

2. **Identify Issues**:
   - Document any code style issues that deviate from the guideline.
   - Provide detailed reasoning for each identified style issue, referencing the relevant section of guide.
   - Suggest specific solutions to improve code style, ensuring that the refactoring strictly adheres to the standards defined in the guideline.

3. **Output Format**:
   - Return your findings in a strict **JSON format** to ensure that the results are machine-readable and easy to parse.
   - Use the following structure:
   ```json
   {{
     "style_review": [
       {{
         "type": "style",
         "file_name": "<Name of the file with full path>",
         "line_number": "<Line number of the identified issue>",
         "line_snippet": "<Original line of code>",
         "issues": [
           "<List all identified style issues>"
         ],
         "suggestions": [
           "<Suggested fixes or improvements>"
         ],
         "reasoning": "<Reasoning for the suggested changes>"
       }}
     ],
     "project_review": "<Provide an overall review of the project's adherence to the coding style. Is the codebase consistent and compliant with the style guide?>"
   }}
   
4. Validation and Final Answer:
   Validate that the JSON is complete, accurate, and strictly adheres to the specified structure.
   If no style issues are found, explicitly state this in the project_review section. Give your answer in Russian.'''

def standards_prompt(guide, code): 
    return f'''You are a senior software engineer in an IT company. Your task is to perform a **compliance review** for the provided code and project structure, ensuring that the code adheres strictly to the standards outlined in `{guide}`. Analyze the code `{code}` and the project setup to identify any deviations or non-compliance with the specified guidelines.

### **Instructions**:

1. **Review Code for Compliance**:
   - Examine the project structure and code to ensure full compliance with the standards from  guide.
   - Focus areas for the review include:
     - **Settings**: Ensure that all settings are passed as environment variables and are structured in `settings.py` in relevant adapters (e.g., for database, HTTP API). Settings should inherit from `BaseSettings` using Pydantic. Verify that the composite pattern is applied correctly for settings instantiation and injection.
     - **Error Handling**: Ensure that errors in the application are abstracted from the clients. Business logic errors should be handled within the service layer and adapted appropriately in the adapter layer.
     - **Date Handling**: Verify that dates are stored and used in UTC in the database, and correctly transformed for the frontend. Ensure correct usage of naive and aware dates.
     - **Logging**: Ensure that `print` statements are not used and that the logging is configured using the `logging` module with the specified format. Verify that the `python-json-logger` package is used for JSON logging if needed.
     - **Reports and Analytics**: Ensure that SQL queries are not overly dependent on database dialects, and repositories are used appropriately for analytics and reports.
     - **Transactions**: Ensure that transactions are managed using the "Unit of Work" pattern, and manual transaction handling is avoided.
     - **Asynchronous Code**: Ensure that asynchronous solutions are justified and used appropriately.
     - **Dependencies Management**: Verify that libraries like `pandas` and `numpy` are only used in data science modules, and check for unnecessary dependencies outside these modules.
     - **WebSockets**: Verify that WebSocket connections are implemented using RabbitMQ with the Stomp over WebSocket plugin where needed.
     - **Authorization**: Ensure that authorization is handled using JWT tokens provided by Keycloak, with the token processed using the `pyjwt` package.

2. **Identify Issues**:
   - Identify any deviations or violations of the standards described in guide.
   - Document each issue clearly, providing reasoning for why it violates the standard and referencing the appropriate sections from guide.
   - Suggest fixes or improvements to bring the code and project structure into compliance with the standards.

3. **Output Format**:
   - Return your findings in **strict JSON format**, ensuring the output is machine-readable and easy to parse.
   - Use the following structure for the response
   - Do not comment auto-generated code(Which is usually in folders started with .)
   ```json
   {{
     "compliance_review": [
       {{
         "type": "non-compliance",
         "file_name": "<name of the file with full path from code>",
         "line_number": "<Line number of the identified issue>",
         "line_snippet": "<Original code or file structure snippet>",
         "issues": [
           "<List all identified compliance issues>"
         ],
         "suggestions": [
           "<Suggested fixes or improvements>"
         ],
         "reasoning": "<Reasoning for the suggested changes>"
       }}
     ],
     "project_review": "<Overall review of the project's compliance with the standards. Does the project adhere to the principles outlined in guide? Is the architecture and code consistent with the described standards?>"
   }}
Validation and Final Answer:
Ensure that the JSON is complete, accurate, and strictly follows the specified structure.
If no issues are found, explicitly state this in the project_review section, confirming full compliance. Avoid commenting auto-generated files. Give your answer in Russian.'''
