
from inference import prompts

prompt_dict = {
    
    'naming': prompts.naming_prompt, 
    'architecture': prompts.architecture_prompt, 
    'structure' : prompts.structure_prompt,
    'package' : prompts.package_prompt, 
    'style' : prompts.style_prompt, 
    'standards' : prompts.standards_prompt,
    
    
}

def get_inference(check_for, guideline_path, code):
    
    prompt_func = prompt_dict[check_for]

    from langchain_ollama import ChatOllama

    
    #ngrok_url = 
#(base_url=ngrok_url,
    url = 'https://still-weekly-tortoise.ngrok-free.app/' #""http://localhost:11434
    ollama = ChatOllama (base_url=url, model='dagbs/qwen2.5-coder-7b-instruct-abliterated',temperature=0, num_ctx=35000)

#    response = ollama.invoke(messages=[
#      { 
#        'role': 'user',
#            'content': 
#          
#      }], options={'num_ctx': 35000, 'temperature': 0,  })  #'num_batch': 2024, 'top_p':1,
#
#
    with open(guideline_path, 'r', encoding='utf-8') as file:
        guide = file.read()

    # Prepare your messages in the correct format
    messages = [
        {
            'role': 'user',
            'content': prompt_func(guide, code)
        }
    ]

    # Call invoke with the correct input
    response = ollama.invoke(input=messages,) # options={'num_ctx': 35000, 'temperature': 0}

    
    return response.content

